export const LOGOUT_SUCCESS ='logout-success';
export const LOGIN_SUCCESS ='login-success';
export const ADMIN_LOGOUT_SUCCESS ='admin-logout-success';
export const ADMIN_LOGIN_SUCCESS ='admin-login-success';
export const ANSWER_SURVEY_SUCCESS='answer-survey-success';
export const GET_USER_DETAILS_SUCCESS='get-user-details';
export const CLEAR_USER_DETAILS_SUCCESS='clear-user-details-success';
export const USER_UPDATE_SUCCESS='user-update-success';