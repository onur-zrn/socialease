import React, { Component } from 'react'

export default class ClubSelection extends Component {
    render() {
        return (
            <div>
                Club Selection
            </div>
        )
    }
}
