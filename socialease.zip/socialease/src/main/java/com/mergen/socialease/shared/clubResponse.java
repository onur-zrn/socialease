package com.mergen.socialease.shared;

import com.mergen.socialease.model.Club;
import com.mergen.socialease.model.SubClub;
import com.mergen.socialease.model.Question;

import java.util.ArrayList;

public class clubResponse {

    private ArrayList<Club> clubList;
}
