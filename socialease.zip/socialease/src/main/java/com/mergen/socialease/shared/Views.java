package com.mergen.socialease.shared;

public interface Views {

	class Base{
		
	}
}
